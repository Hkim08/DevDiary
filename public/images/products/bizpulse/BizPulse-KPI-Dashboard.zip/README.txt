╔══════════════════════════════════════════════════════════════════╗
║         BIZPULSE — BUSINESS KPI DASHBOARD  v2.1                  ║
║         One-Time Purchase · No Subscriptions · Works Offline     ║
╚══════════════════════════════════════════════════════════════════╝

Thank you for your purchase! You now own a professional business
intelligence dashboard that runs entirely in your browser — no
installation, no accounts, no internet required (except for the
optional AI analysis feature).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

WHAT'S IN THIS BUNDLE
━━━━━━━━━━━━━━━━━━━━━
  BizPulse-Dashboard.html       ← MAIN PRODUCT (open this!)
  README.txt                    ← This file
  QUICK-START.txt               ← 5-minute setup guide
  LICENSE.txt                   ← Your usage rights
  bonus/
    KPI-Benchmarks-by-Industry.txt   ← Industry benchmark guide
    AI-Prompt-Cheatsheet.txt         ← 20 AI analysis prompts
    Gumroad-Product-Description.txt  ← (For resellers/affiliates)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HOW TO OPEN
━━━━━━━━━━━
1. Double-click   BizPulse-Dashboard.html
2. It opens in your default browser (Chrome, Firefox, Edge, Safari)
3. That's it. No installation needed.

Works on: Windows, Mac, Linux, Chromebook
Works offline: YES (except AI diagnosis tab)
Mobile: YES (responsive layout)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DASHBOARD FEATURES
━━━━━━━━━━━━━━━━━
  ✓ 12-month revenue, expense & profit tracking
  ✓ Lead → Customer conversion funnel
  ✓ 5 auto-calculated KPI cards (Revenue, Profit, Margin,
    Conversion Rate, Customers)
  ✓ 4 interactive charts (bar, line, funnel, margin %)
  ✓ Business Health Score (0–100 gauge)
  ✓ Smart Alerts engine (8 automatic risk/opportunity signals)
  ✓ Full monthly breakdown table with MoM % change
  ✓ CSV export for further analysis
  ✓ Print-ready report view
  ✓ AI Business Diagnosis (requires free Anthropic API key)
  ✓ 4 one-click AI quick questions

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

THE AI DIAGNOSIS FEATURE
━━━━━━━━━━━━━━━━━━━━━━━━
The AI tab supports three providers: Anthropic Claude, OpenAI
ChatGPT, and Google Gemini. Pick your preferred model and get
a plain-language analysis of your specific business data.

  ► Get a FREE API key from any provider:
     - Claude:   https://console.anthropic.com
     - ChatGPT:  https://platform.openai.com/api-keys
     - Gemini:   https://aistudio.google.com/apikey
  ► Select your provider in the dropdown
  ► Paste your key in the "AI Diagnosis" tab
  ► Click "ANALYZE BUSINESS"

COST: API usage is extremely low. A full analysis costs
approximately $0.002–0.005 (less than half a cent). Your key is
never stored or transmitted anywhere other than the API provider.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TIPS FOR BEST RESULTS
━━━━━━━━━━━━━━━━━━━━━
• Enter at least 3 months of data for meaningful trend analysis
• Fill in your Target Monthly Revenue and Margin % for gap alerts
• Use "Load Sample Data" to explore all features before entering
  your real numbers
• Export CSV monthly to build a historical archive

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SUPPORT
━━━━━━━
Questions? Issues? Reply to your Gumroad purchase receipt email.
We respond within 24 hours, Monday–Friday.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
